import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title="Kalaburagi Bus Intelligence", page_icon="🚌", layout="wide")

st.title("🚌 Kalaburagi City Bus | Ticket Analytics Dashboard")
st.caption("Solvathon 2026 • Problem Statement 3 • Actual department sample data")

DATA_FILE = Path(__file__).parent / "bus_ticket_data.xlsx"

@st.cache_data
def load_data(file_bytes=None):
    if file_bytes is not None:
        raw = pd.read_excel(file_bytes)
    else:
        raw = pd.read_excel(DATA_FILE)
    raw.columns = [str(c).strip() for c in raw.columns]
    required = ["Waybill Number", "Ticket Number", "From Stop", "To Stop",
                "Date", "Time", "Total Psgr", "Coll Amt", "Uncoll Amt"]
    missing = [c for c in required if c not in raw.columns]
    if missing:
        raise ValueError("Missing expected columns: " + ", ".join(missing))
    d = raw[required].copy()
    d["Date"] = pd.to_datetime(d["Date"], errors="coerce")
    d["Time"] = pd.to_datetime(d["Time"].astype(str), format="%H:%M:%S", errors="coerce")
    for c in ["Total Psgr", "Coll Amt", "Uncoll Amt"]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    d["From Stop"] = d["From Stop"].astype("string").str.strip()
    d["To Stop"] = d["To Stop"].astype("string").str.strip()
    d["Hour"] = d["Time"].dt.hour
    d["Journey"] = d["From Stop"].fillna("Unknown") + " → " + d["To Stop"].fillna("Unknown")
    return d

st.sidebar.header("Data")
uploaded = st.sidebar.file_uploader("Upload updated Excel or CSV", type=["xlsx", "xls", "csv"])
try:
    if uploaded:
        if uploaded.name.lower().endswith(".csv"):
            @st.cache_data
            def read_csv_bytes(b):
                return pd.read_csv(b)
            raw_upload = read_csv_bytes(uploaded.getvalue())
            # Use the same validation/cleaning rules as Excel
            raw_upload.columns = [str(c).strip() for c in raw_upload.columns]
            needed = ["Waybill Number", "Ticket Number", "From Stop", "To Stop", "Date", "Time", "Total Psgr", "Coll Amt", "Uncoll Amt"]
            if not all(c in raw_upload.columns for c in needed):
                st.error("Uploaded CSV does not contain the expected column names. Check the data dictionary.")
                st.stop()
            d = raw_upload[needed].copy()
            d["Date"] = pd.to_datetime(d["Date"], errors="coerce")
            d["Time"] = pd.to_datetime(d["Time"].astype(str), format="%H:%M:%S", errors="coerce")
            for c in ["Total Psgr", "Coll Amt", "Uncoll Amt"]:
                d[c] = pd.to_numeric(d[c], errors="coerce")
            d["From Stop"] = d["From Stop"].astype("string").str.strip()
            d["To Stop"] = d["To Stop"].astype("string").str.strip()
            d["Hour"] = d["Time"].dt.hour
            d["Journey"] = d["From Stop"].fillna("Unknown") + " → " + d["To Stop"].fillna("Unknown")
        else:
            d = load_data(uploaded)
    else:
        d = load_data()
except Exception as e:
    st.error(f"Could not read the dataset: {e}")
    st.stop()

st.sidebar.header("Filters")
valid_dates = d["Date"].dropna()
if valid_dates.empty:
    st.error("No valid dates found in the Date column.")
    st.stop()
date_min, date_max = valid_dates.min().date(), valid_dates.max().date()
date_range = st.sidebar.date_input("Travel date range", value=(date_min, date_max), min_value=date_min, max_value=date_max)
f = d.copy()
if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    f = f[(f["Date"].dt.date >= date_range[0]) & (f["Date"].dt.date <= date_range[1])]
elif date_range:
    f = f[f["Date"].dt.date == date_range]
stops = sorted(set(f["From Stop"].dropna().astype(str)) | set(f["To Stop"].dropna().astype(str)))
chosen_stops = st.sidebar.multiselect("Stops (either boarding or destination)", stops)
if chosen_stops:
    f = f[f["From Stop"].isin(chosen_stops) | f["To Stop"].isin(chosen_stops)]
st.caption(f"Showing {len(f):,} ticket records from {len(d):,} rows in the loaded file.")

# These fields are presented exactly as named in the source; do not relabel as net revenue.
a,b,c,e = st.columns(4)
a.metric("Ticket records", f"{len(f):,}")
b.metric("Passengers recorded", f"{int(f['Total Psgr'].fillna(0).sum()):,}")
c.metric("Coll Amt total", f"₹{f['Coll Amt'].fillna(0).sum():,.0f}")
e.metric("Uncoll Amt total", f"₹{f['Uncoll Amt'].fillna(0).sum():,.0f}")
st.info("Important data note: the source has one date only (20-Oct-2026). 'Coll Amt' and 'Uncoll Amt' are shown separately using the original column names. Confirm their exact accounting meaning with Solvathon/Bus Department before calling either one total revenue or combining them.")

tab1, tab2, tab3, tab4 = st.tabs(["Overview", "Stop & Journey Analysis", "Time Patterns", "Data Quality"])

with tab1:
    left,right = st.columns(2)
    with left:
        by_from = f.groupby("From Stop", dropna=False)["Total Psgr"].sum().nlargest(12).reset_index()
        st.subheader("Top boarding stops by recorded passengers")
        st.plotly_chart(px.bar(by_from, x="Total Psgr", y="From Stop", orientation="h", title="Top 12 boarding stops"), use_container_width=True)
    with right:
        by_to = f.groupby("To Stop", dropna=False)["Total Psgr"].sum().nlargest(12).reset_index()
        st.subheader("Top destination stops by recorded passengers")
        st.plotly_chart(px.bar(by_to, x="Total Psgr", y="To Stop", orientation="h", title="Top 12 destination stops"), use_container_width=True)
    st.subheader("Collection fields by boarding stop")
    stop_money = f.groupby("From Stop", dropna=False)[["Coll Amt","Uncoll Amt"]].sum().reset_index().sort_values("Coll Amt", ascending=False).head(15)
    st.plotly_chart(px.bar(stop_money, x="From Stop", y=["Coll Amt","Uncoll Amt"], barmode="group"), use_container_width=True)

with tab2:
    st.subheader("Most common stop-to-stop journeys")
    journey = f.groupby("Journey", dropna=False).agg(Ticket_records=("Ticket Number","size"), Recorded_passengers=("Total Psgr","sum"), Coll_Amt=("Coll Amt","sum"), Uncoll_Amt=("Uncoll Amt","sum")).reset_index().sort_values("Ticket_records", ascending=False).head(20)
    st.plotly_chart(px.bar(journey.sort_values("Ticket_records"), x="Ticket_records", y="Journey", orientation="h", title="Top 20 journeys by ticket-record count"), use_container_width=True)
    st.dataframe(journey, use_container_width=True, hide_index=True)

with tab3:
    st.subheader("Ticket activity by hour")
    hourly = f.dropna(subset=["Hour"]).groupby("Hour").agg(Ticket_records=("Ticket Number","size"), Recorded_passengers=("Total Psgr","sum")).reset_index()
    if not hourly.empty:
        st.plotly_chart(px.line(hourly, x="Hour", y=["Ticket_records","Recorded_passengers"], markers=True, title="Hourly ticket records and recorded passengers"), use_container_width=True)
    else:
        st.warning("No usable time values found.")
    st.caption("This shows ticket issue/record time from the Time column. Confirm with the department what event that timestamp represents.")

with tab4:
    st.subheader("Data quality checks")
    quality = pd.DataFrame({
        "Check": ["Rows loaded", "Missing destination", "Missing date", "Unparseable time", "Zero passenger rows", "Duplicate (Waybill Number + Ticket Number)", "Rows with negative Coll/Uncoll amount"],
        "Result": [len(d), int(d["To Stop"].isna().sum()), int(d["Date"].isna().sum()), int(d["Time"].isna().sum()), int((d["Total Psgr"]==0).sum()), int(d.duplicated(["Waybill Number","Ticket Number"]).sum()), int(((d[["Coll Amt","Uncoll Amt"]]<0).any(axis=1)).sum())]
    })
    st.dataframe(quality, use_container_width=True, hide_index=True)
    st.caption("The workbook also contains an extra mostly-empty column ('Unnamed: 9'); it is not used in the dashboard. Review unusual values before final submission.")
    st.subheader("Filtered ticket records")
    st.dataframe(f.drop(columns=["Hour","Journey"], errors="ignore"), use_container_width=True, hide_index=True)

st.divider()
st.caption("Prototype for Kalaburagi city-service ticket data. Forecasting is intentionally not shown because this uploaded workbook contains only one service date; more historical dates are needed for a defensible forecast.")
