KALABURAGI BUS TICKET DASHBOARD — QUICK START (Windows)

1. Install Python 3.11+ from https://www.python.org/downloads/
   During installation, tick "Add python.exe to PATH".
2. Install Visual Studio Code from https://code.visualstudio.com/
3. Extract this ZIP to a folder you can find, e.g. Desktop.
4. Open VS Code > File > Open Folder > select Kalaburagi_Bus_Dashboard.
5. In VS Code choose Terminal > New Terminal.
6. Run: py -m venv .venv
7. Run: .venv\Scripts\activate
8. Run: python -m pip install -r requirements.txt
9. Run: python -m streamlit run app.py
10. A browser tab should open with the dashboard.

The Excel workbook is included as bus_ticket_data.xlsx. The app can also accept an updated
CSV/Excel file from the sidebar if it has the same expected column headers.

DATA INTERPRETATION CAUTIONS
- Source columns: Waybill Number, Ticket Number, From Stop, To Stop, Date, Time,
  Total Psgr, Coll Amt, Uncoll Amt, plus an extra mostly blank column.
- The provided workbook has one date only (20-Oct-2026); forecasting is not defensible
  from one day. Get more days of data before presenting forecasts.
- Do not assume Coll Amt + Uncoll Amt is revenue or that either is a fare category;
  confirm definitions with Solvathon/Bus Department.
- Ticket Number repeats across waybills; the pair (Waybill Number, Ticket Number)
  is unique in this file. Do not call rows unique passengers.
